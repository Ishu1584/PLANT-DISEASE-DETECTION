# 🌿 Plant Disease Detection using NLP and Deep Learning

A light-weight college project that follows the syllabus **Unit-1 → Unit-3** step by step.
Everything trains on a normal laptop **CPU in a few minutes** (small images, small models, ≤ 300 images per class).

> **Idea:** A farmer can upload a leaf photo (→ **CNN**) and/or type what he sees (→ **NLP + Bi-LSTM**).
> The system combines both and gives the disease name with treatment advice.

## Syllabus ↔ project map

| Syllabus unit | Topics covered | File |
|---|---|---|
| **NLP fundamentals** | tokenization, word frequency, stop words, stemming, lemmatization, POS tagging, Bag-of-Words, TF-IDF, n-grams | `step1_nlp_preprocessing.py`, `nlp_utils.py` |
| **Unit-1 Deep-learning basics** | neuron, weights & bias, activation (ReLU, softmax), forward propagation, cost function, back-propagation, under/over-fitting, validation & test sets, regularization (dropout, L2), framework (Keras/TensorFlow) | `step2_ann.py` (NumPy-from-scratch ANN + Keras ANN) |
| **Unit-2 CNN** | convolution, filters, padding, pooling, weight sharing, ANN vs CNN, LeNet-style architecture, performance metrics (precision/recall/F1, confusion matrix), model deployment | `step3_cnn.py`, `app.py` |
| **Unit-3 RNN** | text pre-processing, word encoding, word embedding, Simple RNN vs LSTM vs Bi-LSTM, many-to-one RNN | `step4_rnn_text.py` |

## Folder layout
```
plant_disease_detection/
├── step1_nlp_preprocessing.py   # NLP basics (prints results + saves a figure)
├── step2_ann.py                 # ANN from scratch + overfitting demo
├── step3_cnn.py                 # CNN for leaf images  -> models/cnn_model.keras
├── step4_rnn_text.py            # RNN / LSTM / Bi-LSTM -> models/text_model.keras
├── app.py                       # Streamlit web app
├── inference.py  common.py  nlp_utils.py  knowledge_base.py
├── data/images/<class>/*.jpg    # leaf images (you add)
├── data/symptoms.csv            # text dataset (included, 480 sentences)
├── tools/                       # make_demo_images.py, make_symptoms.py
└── outputs/                     # graphs are saved here
```

## How to run in VS Code

1. **Install** Python 3.10–3.12 and the VS Code *Python* extension.
2. Unzip, then **File → Open Folder…** → `plant_disease_detection`.
3. Open the terminal (**Ctrl + `**) and create a virtual environment  
   Windows: `python -m venv venv` then `venv\Scripts\activate`  
   Mac/Linux: `python3 -m venv venv` then `source venv/bin/activate`  
   (Windows PowerShell error? run `Set-ExecutionPolicy -Scope Process Bypass` first.)  
   Then **Ctrl+Shift+P → Python: Select Interpreter →** choose `venv`.
4. `pip install -r requirements.txt`
5. **Add images** (choose one):
   * **Real data:** download *PlantVillage* from Kaggle and copy these 4 folders into `data/images/`:
     `Tomato___Early_blight`, `Tomato___Late_blight`, `Tomato___Leaf_Mold`, `Tomato___healthy`  
     (names must match exactly; only the first 300 images of each folder are used).
   * **Quick test without downloading:** `python tools/make_demo_images.py` (fake images, only to check that the code runs).
6. Run the steps **in order**:
   ```
   python step1_nlp_preprocessing.py
   python step2_ann.py
   python step3_cnn.py
   python step4_rnn_text.py
   ```
   Graphs appear in `outputs/` (open them in VS Code).
7. Start the app: `streamlit run app.py` (opens http://localhost:8501).  
   Or in the terminal: `python inference.py --image leaf.jpg --text "white mould under the leaves"`

NLTK data (stop-words, wordnet) downloads automatically the first time (needs internet once).

## Troubleshooting
* *Slow?* Lower `MAX_PER_CLASS` in `common.py` (e.g. 150) or `epochs` in `step3_cnn.py`.
* *`No images` error* → do step 5.
* *TensorFlow won't install* → check `python --version` (use 3.10–3.12).
* *Streamlit says no models* → run steps 3 and 4 first.

## Explaining it to your supervisor (cheat sheet)
* **Why CNN for images?** An ANN flattens the picture (3,072 inputs → 800k weights in the first layer) and loses spatial structure. A CNN uses small shared filters (*weight sharing*), so it needs far fewer parameters – compare the numbers printed in `step3_cnn.py`. The feature maps in `outputs/step3_cnn.png` show what the first filter detects (edges / spots).
* **Why LSTM for text?** A simple RNN forgets early words in a sentence (vanishing gradient); LSTM has gates to keep important information; Bi-LSTM reads the sentence in both directions. `step4_rnn_text.py` trains all three and compares them.
* **Why preprocess text?** Stop-words add noise; lemmatization merges *leaf/leaves*. We keep *no/not* because "no spots" ≠ "spots".
* **Overfitting?** Training accuracy ≫ validation accuracy. Remedies shown: dropout, L2, early stopping, data augmentation, a separate validation/test split (70/15/15).
* **Fusion:** `final = 0.6 × CNN + 0.4 × text model`.
* **Limitations:** PlantVillage photos have clean backgrounds, so field photos may perform worse; the text dataset is template-generated, so replace it with real farmer descriptions for better results.
* **Future work:** transfer learning (MobileNetV2), pretrained GloVe/Word2Vec embeddings, more crops, attention mechanism, mobile deployment (TensorFlow Lite).
