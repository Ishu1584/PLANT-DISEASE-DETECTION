"""Streamlit web app.   Run:  streamlit run app.py"""
import streamlit as st
from PIL import Image

import nlp_utils as nu
from inference import diagnose, models_ready

st.set_page_config(page_title="Plant Disease Detection", page_icon="🌿", layout="centered")
st.markdown("""
<style>
.hero{background:linear-gradient(135deg,#1b5e20,#66bb6a);padding:1.6rem 1.2rem;border-radius:16px;color:white;margin-bottom:1rem}
.hero h1{margin:0;font-size:2rem;color:white}.hero p{margin:.3rem 0 0;opacity:.95}
.card{background:#f1f8e9;border-left:6px solid #2e7d32;padding:1rem 1.2rem;border-radius:10px;color:#1b1b1b;white-space:pre-line}
</style>
<div class="hero"><h1>🌿 Plant Disease Detection</h1>
<p>Deep Learning (CNN) + NLP (Bi-LSTM) &nbsp;|&nbsp; upload a leaf photo, describe the symptoms, or do both</p></div>
""", unsafe_allow_html=True)

img_ok, txt_ok = models_ready()
if not (img_ok or txt_ok):
    st.error("No trained models found. Run step3_cnn.py and step4_rnn_text.py first (see README).")
    st.stop()

tab1, tab2 = st.tabs(["🔍 Diagnose", "📚 How it works"])

with tab1:
    c1, c2 = st.columns(2)
    with c1:
        file = st.file_uploader("Leaf photo", type=["jpg", "jpeg", "png"], disabled=not img_ok)
        img = Image.open(file) if file else None
        if img:
            st.image(img, use_container_width=True)
    with c2:
        text = st.text_area("Describe the symptoms (optional)", height=170, disabled=not txt_ok,
                            placeholder="e.g. brown spots with yellow rings on the lower leaves")
    if st.button("Diagnose", type="primary", use_container_width=True):
        try:
            label, conf, ranked, rep, ip, tp = diagnose(img, text)
            st.metric("Prediction", label.replace("___", " - ").replace("_", " "), f"{conf:.0%} confidence")
            st.markdown(f'<div class="card">{rep}</div>', unsafe_allow_html=True)
            st.subheader("Probabilities")
            st.bar_chart({k.replace("___", " - ").replace("_", " "): v for k, v in ranked})
            if ip and tp:
                a, b = st.columns(2)
                a.caption("Image model (CNN) says"); a.write(max(ip, key=ip.get).replace("___", " - "))
                b.caption("Text model (Bi-LSTM) says"); b.write(max(tp, key=tp.get).replace("___", " - "))
            if text and text.strip():
                with st.expander("NLP preprocessing of your text"):
                    t = nu.tokenize(text); s = nu.remove_stopwords(t)
                    st.write("**Tokens:**", t); st.write("**After stop-word removal:**", s)
                    st.write("**After lemmatization:**", nu.lemmatize(s))
        except ValueError as e:
            st.warning(str(e))

with tab2:
    st.markdown("""
**Pipeline**
1. **Image → CNN** : 64×64 leaf photo → 3 × (Conv + MaxPool) → Dense → Softmax
2. **Text → NLP** : tokenize → stop words → lemmatize → word encoding → Embedding → Bi-LSTM → Softmax
3. **Fusion** : `0.6 × image probabilities + 0.4 × text probabilities`
4. **Advice** : the predicted class is turned into a readable report (cause, treatment, prevention)
""")
