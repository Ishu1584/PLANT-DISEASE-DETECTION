"""Create data/symptoms.csv (small text dataset for the RNN/LSTM).  Run: python tools/make_symptoms.py"""
import csv, random
from pathlib import Path
random.seed(42)
OUT = Path(__file__).resolve().parent.parent / "data" / "symptoms.csv"
OPEN = ["I see", "My plant has", "There are", "The leaves show", "Noticed", "My tomatoes have",
        "I found", "My crop shows", "Observed", "The foliage has"]
TAIL = ["", "", "since last week", "after the rain", "spreading slowly", "on the lower leaves", "this season", "in my field"]
SYM = {
 "Tomato___Early_blight": ["brown spots with concentric rings", "yellow halo around brown target spots",
    "lower leaves yellowing with ringed lesions", "dark bullseye spots on old leaves", "dark spots with rings and stem lesions"],
 "Tomato___Late_blight": ["large greasy grey green blotches", "white mould on leaf undersides after humid nights",
    "brown firm rot on fruit and blackened leaves", "fast spreading water soaked lesions", "leaves browning and dying within days of rain"],
 "Tomato___Leaf_Mold": ["pale yellow spots on the upper leaf surface", "olive green velvety mould under the leaves",
    "yellow patches above and fuzzy mold below", "mouldy leaves in greenhouse humidity", "leaves curling with yellow spots and olive mold"],
 "Tomato___healthy": ["fresh green leaves", "no spots or mould", "healthy leaves and normal growth",
    "clean leaves without any lesions", "plant looks perfect and green"],
}
rows = []
for label, phrases in SYM.items():
    for _ in range(120):
        t = f"{random.choice(OPEN)} {random.choice(phrases)} {random.choice(TAIL)}".strip().lower()
        rows.append((t, label))
random.shuffle(rows)
with open(OUT, "w", newline="") as f:
    w = csv.writer(f); w.writerow(["text", "label"]); w.writerows(rows)
print(f"Wrote {len(rows)} rows -> {OUT}")
