"""Create SYNTHETIC leaf pictures so you can test the code without downloading a dataset.
(Not real data - use PlantVillage for your actual results.)   Run: python tools/make_demo_images.py"""
import random
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
random.seed(1); np.random.seed(1)
ROOT = Path(__file__).resolve().parent.parent / "data" / "images"
CLASSES = {"Tomato___Early_blight": ((150, 90, 30), 9), "Tomato___Late_blight": ((60, 60, 50), 4),
           "Tomato___Leaf_Mold": ((200, 200, 80), 14), "Tomato___healthy": (None, 0)}
for cls, (col, n) in CLASSES.items():
    d = ROOT / cls; d.mkdir(parents=True, exist_ok=True)
    for i in range(90):
        img = Image.fromarray(np.random.randint(200, 255, (64, 64, 3), dtype=np.uint8))
        dr = ImageDraw.Draw(img)
        g = (random.randint(20, 70), random.randint(110, 170), random.randint(20, 70))
        dr.ellipse((6, 9, 58, 55), fill=g)
        dr.line((6, 32, 58, 32), fill=(g[0] + 30, g[1] + 40, g[2] + 20), width=1)
        if col:
            for _ in range(max(1, n + random.randint(-2, 2))):
                x, y, r = random.randint(15, 49), random.randint(17, 46), random.randint(1, 4)
                dr.ellipse((x - r, y - r, x + r, y + r), fill=col)
        img.save(d / f"{cls}_{i:03d}.jpg")
print("Demo images created in", ROOT)
