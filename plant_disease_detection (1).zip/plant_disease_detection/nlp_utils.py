"""NLP preprocessing pipeline (Unit-1 / Unit-3 topics): tokenization, stop-word removal,
stemming, lemmatization, POS tagging."""
import re

import nltk
from nltk.stem import PorterStemmer, WordNetLemmatizer


def _ensure(pkg, path):
    try:
        nltk.data.find(path)
        return True
    except LookupError:
        try:
            return bool(nltk.download(pkg, quiet=True))
        except Exception:
            return False


_ensure("stopwords", "corpora/stopwords")
_ensure("wordnet", "corpora/wordnet")
_HAS_TAGGER = _ensure("averaged_perceptron_tagger_eng", "taggers/averaged_perceptron_tagger_eng")

from nltk.corpus import stopwords  # noqa: E402

# keep negations: "no spots" means something very different from "spots"
STOP = set(stopwords.words("english")) - {"no", "not", "nor", "without"}
_stemmer = PorterStemmer()
_lemmatizer = WordNetLemmatizer()


def tokenize(text):
    return re.findall(r"[a-z]+", text.lower())


def remove_stopwords(tokens):
    return [t for t in tokens if t not in STOP]


def stem(tokens):
    return [_stemmer.stem(t) for t in tokens]


def lemmatize(tokens):
    return [_lemmatizer.lemmatize(t) for t in tokens]


def pos_tag(tokens):
    if not _HAS_TAGGER:
        return [(t, "n/a") for t in tokens]
    return nltk.pos_tag(tokens)


def preprocess(text):
    """Full pipeline used before the text goes into the LSTM."""
    return " ".join(lemmatize(remove_stopwords(tokenize(text))))
