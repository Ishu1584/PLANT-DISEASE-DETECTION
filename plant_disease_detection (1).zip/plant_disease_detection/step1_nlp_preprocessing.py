"""STEP 1 - NLP fundamentals & text preprocessing  (Unit-1 / Unit-3 preprocessing topics)
Tokenization, word frequency, stop words, stemming vs lemmatization, POS tagging,
Bag-of-Words, TF-IDF, n-grams.            Run:  python step1_nlp_preprocessing.py
"""
from collections import Counter

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

import nlp_utils as nu
from common import OUT_DIR

DOC = ("The tomato leaves show brown spots with yellow rings. The spots are spreading and the leaves are "
       "curling. There is white mould under the leaves after the rain, and the infected leaves are dying.")

print("=" * 60, "\n1. TOKENIZATION & WORD FREQUENCY\n" + "=" * 60)
tokens = nu.tokenize(DOC)
print("Tokens:", tokens)
freq = Counter(tokens).most_common(8)
print("Top words:", freq)

print("\n" + "=" * 60, "\n2. STOP-WORD REMOVAL (compare with original)\n" + "=" * 60)
no_stop = nu.remove_stopwords(tokens)
print(f"Original : {len(tokens)} tokens\nAfter    : {len(no_stop)} tokens\n{no_stop}")

print("\n" + "=" * 60, "\n3. STEMMING vs LEMMATIZATION\n" + "=" * 60)
words = ["leaves", "spots", "spreading", "curling", "infected", "dying", "rotting", "yellowing"]
print(f"{'word':12s}{'stem':12s}{'lemma':12s}")
for w, s, l in zip(words, nu.stem(words), nu.lemmatize(words)):
    print(f"{w:12s}{s:12s}{l:12s}")
print("-> Stemming just chops endings (may give non-words); lemmatization returns real dictionary words.")

print("\n" + "=" * 60, "\n4. PART-OF-SPEECH TAGGING\n" + "=" * 60)
print(nu.pos_tag(no_stop[:8]))

print("\n" + "=" * 60, "\n5. BAG-OF-WORDS, N-GRAMS, TF-IDF\n" + "=" * 60)
docs = ["brown spots with yellow rings on lower leaves",
        "white mould under the leaves after rain",
        "pale yellow spots and olive mould under the leaves",
        "healthy green leaves no spots"]
docs = [nu.preprocess(d) for d in docs]
bow = CountVectorizer()
M = bow.fit_transform(docs)
print("Vocabulary:", list(bow.get_feature_names_out()))
print("BoW matrix:\n", M.toarray())
print("Bigrams  :", list(CountVectorizer(ngram_range=(2, 2)).fit(docs).get_feature_names_out())[:8], "...")
tfidf = TfidfVectorizer()
T = tfidf.fit_transform(docs).toarray()
vocab = tfidf.get_feature_names_out()
for i, d in enumerate(docs):
    top = sorted(zip(vocab, T[i]), key=lambda p: -p[1])[:3]
    print(f"Doc {i + 1} keywords:", [(w, round(float(s), 2)) for w, s in top])

# ---------- picture ----------
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
ax[0].bar([w for w, _ in freq], [c for _, c in freq], color="#2e7d32")
ax[0].set_title("Word frequency distribution"); ax[0].tick_params(axis="x", rotation=45)
im = ax[1].imshow(T, cmap="Greens")
ax[1].set_xticks(range(len(vocab))); ax[1].set_xticklabels(vocab, rotation=90, fontsize=7)
ax[1].set_yticks(range(len(docs))); ax[1].set_yticklabels([f"Doc {i + 1}" for i in range(len(docs))])
ax[1].set_title("TF-IDF scores"); fig.colorbar(im, ax=ax[1])
fig.tight_layout(); fig.savefig(OUT_DIR / "step1_nlp.png", dpi=120)
print("\nSaved figure -> outputs/step1_nlp.png")
