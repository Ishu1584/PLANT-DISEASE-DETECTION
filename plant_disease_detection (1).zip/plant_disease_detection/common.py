"""Shared helpers: paths and image loading (kept small so everything trains on a normal laptop CPU)."""
import json
from pathlib import Path

import numpy as np
from PIL import Image
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parent
IMAGE_DIR = ROOT / "data" / "images"          # data/images/<class_name>/*.jpg
SYMPTOM_CSV = ROOT / "data" / "symptoms.csv"
MODEL_DIR = ROOT / "models"
OUT_DIR = ROOT / "outputs"
MODEL_DIR.mkdir(exist_ok=True)
OUT_DIR.mkdir(exist_ok=True)

CNN_PATH = MODEL_DIR / "cnn_model.keras"
CLASSES_PATH = MODEL_DIR / "classes.json"
NLP_PATH = MODEL_DIR / "text_model.keras"
NLP_CLASSES_PATH = MODEL_DIR / "text_classes.json"

IMG_SIZE = 64            # CNN input size  (64 x 64 x 3)
MAX_PER_CLASS = 300      # limit images per class -> fast CPU training
SEED = 42


def pretty(label: str) -> str:
    plant, _, disease = label.partition("___")
    return f"{plant} - {disease.replace('_', ' ')}"


def load_images(size=IMG_SIZE):
    """Return X (N,size,size,3) in 0..1, y (N,), class_names."""
    if not IMAGE_DIR.exists():
        raise SystemExit("data/images not found - see README step 5.")
    classes = sorted(d.name for d in IMAGE_DIR.iterdir()
                     if d.is_dir() and any(d.glob("*.*")))
    if not classes:
        raise SystemExit("No images in data/images/<class>/ - see README step 5.")
    X, y = [], []
    for idx, c in enumerate(classes):
        files = sorted(f for f in (IMAGE_DIR / c).iterdir()
                       if f.suffix.lower() in {".jpg", ".jpeg", ".png"})[:MAX_PER_CLASS]
        for f in files:
            img = Image.open(f).convert("RGB").resize((size, size))
            X.append(np.asarray(img, dtype="float32") / 255.0)
            y.append(idx)
    X, y = np.array(X), np.array(y)
    print(f"Loaded {len(X)} images, {len(classes)} classes: {classes}")
    CLASSES_PATH.write_text(json.dumps(classes))
    return X, y, classes


def train_val_test(X, y):
    """70% train / 15% validation / 15% test  (syllabus: learning, validation, testing)."""
    X_tr, X_tmp, y_tr, y_tmp = train_test_split(X, y, test_size=0.3, stratify=y, random_state=SEED)
    X_val, X_te, y_val, y_te = train_test_split(X_tmp, y_tmp, test_size=0.5, stratify=y_tmp, random_state=SEED)
    return X_tr, X_val, X_te, y_tr, y_val, y_te
