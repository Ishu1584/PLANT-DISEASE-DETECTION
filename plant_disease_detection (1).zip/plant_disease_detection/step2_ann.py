"""STEP 2 - Artificial Neural Network  (Unit-1: neuron, weights & biases, activation,
forward propagation, back-propagation, cost function, overfitting, regularization)

Part A: a 2-layer ANN written from scratch with NumPy (so you can explain every line).
Part B: the same idea in Keras, with and without regularization (overfitting demo).
Run:  python step2_ann.py
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from common import OUT_DIR, SEED, load_images, train_val_test

X, y, classes = load_images(size=32)               # small 32x32 images for the plain ANN
X = X.reshape(len(X), -1)                           # flatten: 32*32*3 = 3072 inputs
X_tr, X_val, X_te, y_tr, y_val, y_te = train_val_test(X, y)
X_tr, X_val, X_te = [(a - 0.5) / 0.25 for a in (X_tr, X_val, X_te)]   # normalise
n_in, n_cls = X_tr.shape[1], len(classes)


# ------------------------------------------------------------------ Part A: NumPy ANN
class NumpyANN:
    """input -> [weights W1 + bias b1] -> ReLU -> [W2 + b2] -> softmax"""

    def __init__(self, n_in, n_hidden, n_out, lr=0.003):
        rng = np.random.default_rng(SEED)
        self.W1 = rng.normal(0, np.sqrt(2 / n_in), (n_in, n_hidden)); self.b1 = np.zeros(n_hidden)
        self.W2 = rng.normal(0, np.sqrt(2 / n_hidden), (n_hidden, n_out)); self.b2 = np.zeros(n_out)
        self.lr = lr

    def forward(self, X):                                   # ---- forward propagation
        self.X = X
        self.z1 = X @ self.W1 + self.b1                     # weighted sum + bias
        self.a1 = np.maximum(0, self.z1)                    # ReLU activation
        z2 = self.a1 @ self.W2 + self.b2
        e = np.exp(z2 - z2.max(1, keepdims=True))
        self.p = e / e.sum(1, keepdims=True)                # softmax -> probabilities
        return self.p

    def loss(self, y):                                      # ---- cost function (cross-entropy)
        return -np.log(self.p[np.arange(len(y)), y] + 1e-9).mean()

    def backward(self, y):                                  # ---- back-propagation (chain rule)
        n = len(y)
        dz2 = self.p.copy(); dz2[np.arange(n), y] -= 1; dz2 /= n
        dW2, db2 = self.a1.T @ dz2, dz2.sum(0)
        dz1 = (dz2 @ self.W2.T) * (self.z1 > 0)             # derivative of ReLU
        dW1, db1 = self.X.T @ dz1, dz1.sum(0)
        for p, g in ((self.W1, dW1), (self.b1, db1), (self.W2, dW2), (self.b2, db2)):
            p -= self.lr * g                                # gradient descent update

    def predict(self, X):
        return self.forward(X).argmax(1)


print("\n=== Part A: ANN from scratch (NumPy) ===")
net = NumpyANN(n_in, 32, n_cls)
tr_loss, val_acc = [], []
rng = np.random.default_rng(SEED)
for epoch in range(1, 41):
    idx = rng.permutation(len(X_tr))
    for i in range(0, len(idx), 32):                        # mini-batches
        b = idx[i:i + 32]
        net.forward(X_tr[b]); net.backward(y_tr[b])
    net.forward(X_tr); tr_loss.append(net.loss(y_tr))
    val_acc.append((net.predict(X_val) == y_val).mean())
    if epoch % 5 == 0:
        print(f"epoch {epoch:2d}  loss {tr_loss[-1]:.4f}  val_acc {val_acc[-1]:.3f}")
np_test = (net.predict(X_te) == y_te).mean()
print(f"NumPy ANN test accuracy: {np_test:.3f}")

# ------------------------------------------------------------------ Part B: Keras ANN
print("\n=== Part B: Keras ANN - overfitting vs regularization ===")
import tensorflow as tf
from tensorflow.keras import layers, models, regularizers
tf.random.set_seed(SEED)


def keras_ann(regularize):
    reg = regularizers.l2(1e-4) if regularize else None
    m = models.Sequential([layers.Input(shape=(n_in,)),
                           layers.Dense(256, activation="relu", kernel_regularizer=reg)])
    if regularize:
        m.add(layers.Dropout(0.3))                          # regularization
    m.add(layers.Dense(128, activation="relu", kernel_regularizer=reg))
    if regularize:
        m.add(layers.Dropout(0.3))
    m.add(layers.Dense(n_cls, activation="softmax"))
    m.compile("adam", "sparse_categorical_crossentropy", metrics=["accuracy"])
    return m


hist = {}
for name, reg in (("plain ANN", False), ("ANN + Dropout + L2", True)):
    m = keras_ann(reg)
    cb = [tf.keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)] if reg else []
    h = m.fit(X_tr, y_tr, validation_data=(X_val, y_val), epochs=30, batch_size=32, verbose=0, callbacks=cb)
    hist[name] = h.history
    print(f"{name:20s} train_acc {h.history['accuracy'][-1]:.3f} | val_acc {h.history['val_accuracy'][-1]:.3f}"
          f" | test_acc {m.evaluate(X_te, y_te, verbose=0)[1]:.3f} | params {m.count_params():,}")
print("A big gap between train and validation accuracy = overfitting. Regularization shrinks that gap.")

fig, ax = plt.subplots(1, 3, figsize=(15, 4))
ax[0].plot(tr_loss, color="#2e7d32"); ax[0].set_title("NumPy ANN: training loss"); ax[0].set_xlabel("epoch")
ax[1].plot(val_acc, color="#1565c0"); ax[1].set_title("NumPy ANN: validation accuracy"); ax[1].set_xlabel("epoch")
for name, h in hist.items():
    ax[2].plot(h["accuracy"], "--", label=f"{name} train"); ax[2].plot(h["val_accuracy"], label=f"{name} val")
ax[2].set_title("Keras ANN: overfitting vs regularization"); ax[2].legend(fontsize=7); ax[2].set_xlabel("epoch")
fig.tight_layout(); fig.savefig(OUT_DIR / "step2_ann.png", dpi=120)
print("Saved figure -> outputs/step2_ann.png")
