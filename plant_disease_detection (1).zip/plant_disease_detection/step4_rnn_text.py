"""STEP 4 - Recurrent Neural Networks for text  (Unit-3: RNN, LSTM, Bi-LSTM, text pre-processing,
word encoding, word embedding, many-to-one architecture)
Reads a farmer's symptom description and predicts the disease.
Run:  python step4_rnn_text.py           (about 1-2 minutes)
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from tensorflow.keras import layers, models

import nlp_utils as nu
from common import NLP_CLASSES_PATH, NLP_PATH, OUT_DIR, SEED, SYMPTOM_CSV

tf.random.set_seed(SEED)
df = pd.read_csv(SYMPTOM_CSV)
df["clean"] = [nu.preprocess(str(t)) for t in df["text"]]          # tokenize -> stop words -> lemmatize
print(df[["text", "clean"]].head(3).to_string(index=False), "\n")

classes = sorted(df["label"].unique())
y = df["label"].map({c: i for i, c in enumerate(classes)}).to_numpy("int32")
X_tr, X_te, y_tr, y_te = train_test_split(df["clean"].tolist(), y, test_size=0.2, stratify=y, random_state=SEED)


def make_ds(X, y, shuffle=False):
    ds = tf.data.Dataset.from_tensor_slices(([[t] for t in X], y))
    return (ds.shuffle(1000) if shuffle else ds).batch(32)


train_ds, test_ds = make_ds(X_tr, y_tr, True), make_ds(X_te, y_te)


def build(kind):
    vec = layers.TextVectorization(max_tokens=2000, output_sequence_length=20)   # word encoding
    vec.adapt(np.array(X_tr))
    inp = layers.Input(shape=(1,), dtype=tf.string)
    x = vec(inp)
    x = layers.Embedding(2000, 32, mask_zero=True)(x)                            # word embedding
    if kind == "SimpleRNN":
        x = layers.SimpleRNN(32)(x)
    elif kind == "LSTM":
        x = layers.LSTM(32)(x)
    else:
        x = layers.Bidirectional(layers.LSTM(32))(x)                             # Bi-LSTM
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(len(classes), activation="softmax")(x)                    # many-to-one
    m = models.Model(inp, out)
    m.compile("adam", "sparse_categorical_crossentropy", metrics=["accuracy"])
    return m


results, models_ = {}, {}
for kind in ("SimpleRNN", "LSTM", "BiLSTM"):
    print(f"--- training {kind} ---")
    m = build(kind)
    h = m.fit(train_ds, validation_data=test_ds, epochs=12, verbose=0, shuffle=False,
              callbacks=[tf.keras.callbacks.EarlyStopping(patience=3, restore_best_weights=True)])
    acc = m.evaluate(test_ds, verbose=0)[1]
    results[kind], models_[kind] = (acc, h.history), m
    print(f"{kind:10s} test accuracy = {acc:.3f}   params = {m.count_params():,}")

# best test accuracy; on a tie prefer the later (more powerful) model
best = max(results, key=lambda k: (round(results[k][0], 3), list(results).index(k)))
print(f"\nBest model: {best}  -> saved for the app")
models_[best].save(NLP_PATH)
NLP_CLASSES_PATH.write_text(json.dumps(classes))

fig, ax = plt.subplots(1, 2, figsize=(11, 4))
ax[0].bar(results.keys(), [r[0] for r in results.values()], color=["#9e9e9e", "#43a047", "#1b5e20"])
ax[0].set_ylim(0, 1.05); ax[0].set_title("RNN vs LSTM vs Bi-LSTM (test accuracy)")
for k, (_, h) in results.items():
    ax[1].plot(h["val_accuracy"], label=k)
ax[1].set_title("Validation accuracy per epoch"); ax[1].legend(); ax[1].set_xlabel("epoch")
fig.tight_layout(); fig.savefig(OUT_DIR / "step4_rnn.png", dpi=120)

for s in ("brown rings with yellow halo on old leaves", "white mould under the leaves after rain", "no spots, leaves look fine"):
    p = models_[best].predict(tf.constant([[nu.preprocess(s)]]), verbose=0)[0]
    print(f'"{s}" -> {classes[int(p.argmax())]} ({p.max():.0%})')
print("Saved model -> models/text_model.keras and figure -> outputs/step4_rnn.png")
