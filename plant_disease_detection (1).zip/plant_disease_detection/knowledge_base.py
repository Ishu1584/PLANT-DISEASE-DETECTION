"""Simple rule-based advice (NLP report generation)."""
KB = {
    "Tomato___Early_blight": ("fungus Alternaria solani",
        "brown spots with concentric rings and a yellow halo on lower leaves",
        "Remove affected leaves; spray a copper-based fungicide or chlorothalonil.",
        "Mulch the soil, water at the base, rotate crops every year."),
    "Tomato___Late_blight": ("water mould Phytophthora infestans",
        "large greasy grey-green blotches, white mould under leaves, brown fruit rot",
        "Remove and destroy infected plants; apply a fungicide containing mancozeb.",
        "Avoid overhead watering, give plants space, use resistant varieties."),
    "Tomato___Leaf_Mold": ("fungus Passalora fulva",
        "pale yellow spots on top of the leaf and olive-green mould underneath",
        "Lower humidity, improve ventilation, apply a copper fungicide.",
        "Avoid wet leaves, space plants widely in greenhouses."),
    "Tomato___healthy": ("none detected", "uniform green leaves without spots",
        "No treatment required.", "Keep scouting regularly and water at the base."),
}
DEFAULT = ("unknown", "not available",
           "Consult a local agriculture officer for a lab diagnosis.",
           "Practise crop rotation and field sanitation.")


def report(label, confidence):
    cause, symptoms, treatment, prevention = KB.get(label, DEFAULT)
    name = label.replace("___", " - ").replace("_", " ")
    if label.endswith("healthy"):
        head = f"The plant looks healthy ({name}), confidence {confidence:.0%}."
        return "\n".join([head, f"Advice: {treatment} {prevention}"])
    lines = [f"Detected: {name} (confidence {confidence:.0%}).",
             f"Cause: {cause}.", f"Typical symptoms: {symptoms}.",
             f"Treatment: {treatment}", f"Prevention: {prevention}"]
    if confidence < 0.5:
        lines.append("Note: confidence is low - retake a clear, well-lit photo of one leaf.")
    return "\n".join(lines)
