"""Uses the trained CNN (image) and Bi-LSTM (text) together."""
import json
from functools import lru_cache

import numpy as np
import tensorflow as tf
from PIL import Image

import nlp_utils as nu
from common import CLASSES_PATH, CNN_PATH, IMG_SIZE, NLP_CLASSES_PATH, NLP_PATH
from knowledge_base import report

IMAGE_WEIGHT = 0.6        # final = 0.6 * image + 0.4 * text


@lru_cache(maxsize=1)
def _cnn():
    return tf.keras.models.load_model(CNN_PATH), json.loads(CLASSES_PATH.read_text())


@lru_cache(maxsize=1)
def _txt():
    return tf.keras.models.load_model(NLP_PATH), json.loads(NLP_CLASSES_PATH.read_text())


def models_ready():
    return CNN_PATH.exists(), NLP_PATH.exists()


def predict_image(img):
    model, classes = _cnn()
    if not isinstance(img, Image.Image):
        img = Image.open(img)
    arr = np.asarray(img.convert("RGB").resize((IMG_SIZE, IMG_SIZE)), dtype="float32")[None] / 255.0
    return dict(zip(classes, model.predict(arr, verbose=0)[0].tolist()))


def predict_text(text):
    model, classes = _txt()
    p = model.predict(tf.constant([[nu.preprocess(text)]]), verbose=0)[0]
    return dict(zip(classes, p.tolist()))


def diagnose(image=None, text=None):
    if image is None and not (text and text.strip()):
        raise ValueError("Please give a leaf photo, a symptom description, or both.")
    ip = predict_image(image) if image is not None else None
    tp = predict_text(text) if text and text.strip() else None
    if ip and tp:
        probs = {k: IMAGE_WEIGHT * ip.get(k, 0) + (1 - IMAGE_WEIGHT) * tp.get(k, 0) for k in set(ip) | set(tp)}
    else:
        probs = ip or tp
    ranked = sorted(probs.items(), key=lambda kv: -kv[1])
    label, conf = ranked[0]
    return label, conf, ranked, report(label, conf), ip, tp


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--image"); ap.add_argument("--text")
    a = ap.parse_args()
    label, conf, ranked, rep, *_ = diagnose(a.image, a.text)
    print("\n".join(f"{k:25s}{v:.1%}" for k, v in ranked)); print("\n" + rep)
