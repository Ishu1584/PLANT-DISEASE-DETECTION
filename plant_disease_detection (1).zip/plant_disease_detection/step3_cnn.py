"""STEP 3 - Convolutional Neural Network  (Unit-2: convolution, filters, padding/stride, pooling,
weight sharing, ANN vs CNN, LeNet-style architecture, performance metrics, model deployment)
Run:  python step3_cnn.py            (about 1-3 minutes on a normal CPU)
"""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from sklearn.metrics import classification_report, confusion_matrix
from tensorflow.keras import layers, models

from common import CLASSES_PATH, CNN_PATH, IMG_SIZE, OUT_DIR, SEED, load_images, pretty, train_val_test

tf.random.set_seed(SEED)
X, y, classes = load_images()
X_tr, X_val, X_te, y_tr, y_val, y_te = train_val_test(X, y)

# LeNet-style CNN:  [Conv -> ReLU -> MaxPool] x 3  ->  Flatten -> Dense -> Softmax
inp = layers.Input(shape=(IMG_SIZE, IMG_SIZE, 3))
x = layers.RandomFlip("horizontal")(inp)                         # light data augmentation
x = layers.Conv2D(16, 3, padding="same", activation="relu", name="conv1")(x)   # 16 filters 3x3
x = layers.MaxPooling2D(2)(x)                                    # 64 -> 32
x = layers.Conv2D(32, 3, padding="same", activation="relu", name="conv2")(x)
x = layers.MaxPooling2D(2)(x)                                    # 32 -> 16
x = layers.Conv2D(64, 3, padding="same", activation="relu", name="conv3")(x)
x = layers.MaxPooling2D(2)(x)                                    # 16 -> 8
x = layers.Flatten()(x)
x = layers.Dropout(0.4)(x)
x = layers.Dense(64, activation="relu")(x)
out = layers.Dense(len(classes), activation="softmax")(x)
model = models.Model(inp, out)
model.summary()
model.compile("adam", "sparse_categorical_crossentropy", metrics=["accuracy"])

ann_params = (32 * 32 * 3) * 256 + 256
print(f"\nParameters in this CNN: {model.count_params():,}   "
      f"(the first Dense layer of a plain ANN on 32x32 images alone needs {ann_params:,}) -> weight sharing!")

hist = model.fit(X_tr, y_tr, validation_data=(X_val, y_val), epochs=15, batch_size=32, verbose=2,
                 callbacks=[tf.keras.callbacks.EarlyStopping(patience=4, restore_best_weights=True)])

# ---- performance metrics
pred = model.predict(X_te, verbose=0).argmax(1)
print("\nTest accuracy:", round(float((pred == y_te).mean()), 3))
print(classification_report(y_te, pred, labels=range(len(classes)),
                            target_names=[pretty(c) for c in classes], zero_division=0))
cm = confusion_matrix(y_te, pred, labels=range(len(classes)))

# ---- what does the first convolution layer "see"?
sample = X_te[:1]
fmap = models.Model(inp, model.get_layer("conv1").output).predict(sample, verbose=0)[0]

fig = plt.figure(figsize=(14, 7))
ax = fig.add_subplot(2, 3, 1); ax.plot(hist.history["accuracy"], label="train"); ax.plot(hist.history["val_accuracy"], label="val")
ax.set_title("Accuracy"); ax.legend(); ax.set_xlabel("epoch")
ax = fig.add_subplot(2, 3, 2); ax.plot(hist.history["loss"], label="train"); ax.plot(hist.history["val_loss"], label="val")
ax.set_title("Loss"); ax.legend(); ax.set_xlabel("epoch")
ax = fig.add_subplot(2, 3, 3); im = ax.imshow(cm, cmap="Greens"); ax.set_title("Confusion matrix")
ax.set_xticks(range(len(classes))); ax.set_yticks(range(len(classes)))
ax.set_xticklabels([pretty(c) for c in classes], rotation=60, ha="right", fontsize=7)
ax.set_yticklabels([pretty(c) for c in classes], fontsize=7)
for i in range(len(classes)):
    for j in range(len(classes)):
        ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=8)
ax = fig.add_subplot(2, 3, 4); ax.imshow(sample[0]); ax.set_title(f"Input leaf ({pretty(classes[y_te[0]])})"); ax.axis("off")
for k in range(2):
    ax = fig.add_subplot(2, 3, 5 + k); ax.imshow(fmap[:, :, k], cmap="viridis")
    ax.set_title(f"conv1 feature map #{k + 1}"); ax.axis("off")
fig.tight_layout(); fig.savefig(OUT_DIR / "step3_cnn.png", dpi=120)

model.save(CNN_PATH)
CLASSES_PATH.write_text(json.dumps(classes))
print("Saved model -> models/cnn_model.keras  and figure -> outputs/step3_cnn.png")
